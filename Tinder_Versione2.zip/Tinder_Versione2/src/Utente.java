import java.util.HashSet;
import java.util.Set;

public class Utente {

    private String nome;
    private Set<Interesse> listaInteressi;

    public Utente(String nome) {
        this.nome= nome;
        this.listaInteressi = new HashSet<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Set<Interesse> getListaInteressi() {
        return listaInteressi;
    }

    public void aggiungiInteresse(Interesse interesse) {
        this.listaInteressi.add(interesse);
    }

    @Override
    public String toString() {
        return "Utente{" +
                "nome='" + nome + '\'' +
                ", listaInteressi=" + listaInteressi +
                '}';
    }
}
