import java.util.ArrayList;
import java.util.List;

public class TinderLike {

    /* Esercizio TinderLike 🛵

    Scrivere un programma per gestire gli interessi in comune tra le persone.
    In particolare, deve essere possibile gestire una quantità potenzialmente
    infinita di utenti, ognuno con i propri interessi (a ciascun utente può essere
            associato uno o più interessi).
    Ogni interesse ha un codice e un testo.

    Devono essere possibili le seguenti operazioni:
            - inserire un utente e i suoi interessi
- cancellare un utente (e i suoi interessi associati)
- dato un utente u1, ottenere l'utente u2 con più interessi in comune con u1
            - PLUS 🏍:ottenere gli utenti più simili (ossia con più interessi in comune)*/

    private List<Utente> listaUtenti;

    public TinderLike() {
        this.listaUtenti = new ArrayList<>(10);
    }

    public List<Utente> getListaUtenti() {
        return listaUtenti;
    }

    @Override
    public String toString() {
        return "TinderLike{" +
                "listaUtenti=" + listaUtenti +
                '}';
    }

    public void insertUtente(Utente utente) {

        //Con flag non inserisco valori uguali; potevo usare il Set
        boolean flag = true;
        for (Utente utente1 : listaUtenti) {
            if (utente.equals(utente1)) {
                flag = false;
                break;
            }
        }
        if (flag)
            listaUtenti.add(utente);

    }

    public boolean cancelUtente(Utente utente) {
        boolean remove = listaUtenti.remove(utente);
        return remove;
    }

    public Utente obtainSimilarUtente(Utente u1) {
        int count = 0;
        int countmax = 0;
        int indice = 0;
        int indiceu2 = 0;
        for (Utente utente : listaUtenti) {
            if (!utente.equals(u1)) {
                for (Interesse interesse : utente.getListaInteressi()) {
                    for (Interesse interesseu1 : u1.getListaInteressi()) {
                        if (interesseu1.equals(interesse)) {
                            count++;
                        }

                    }
                }
            }
            if(count > countmax){
                indiceu2 = indice;
                countmax = count;
            }
            count = 0;
            indice++;

        }
        Utente u2 = listaUtenti.get(indiceu2);
        return u2;
    }

    public ArrayList<Utente> obtain2MostSimilarUtenti(){
        int count = 0;
        int countmax = 0;
        ArrayList<Utente> lista2MostSimilarUt = new ArrayList<>(2);

        for (int i = 1; i < listaUtenti.size(); i++) {
            for (int j = 0; j < i; j++) {
                for (Interesse interessei : listaUtenti.get(i).getListaInteressi()) {
                    for (Interesse interessej : listaUtenti.get(j).getListaInteressi()) {
                        if(interessei.equals(interessej))
                            count++;
                    }
                }
                if(count > countmax){
                    countmax = count;
                    lista2MostSimilarUt.clear();
                    lista2MostSimilarUt.add(listaUtenti.get(i));
                    lista2MostSimilarUt.add(listaUtenti.get(j));
                }
                count = 0;
            }
        }
        return lista2MostSimilarUt;
    }

}






