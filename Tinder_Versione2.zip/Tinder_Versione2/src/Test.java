public class Test {

    static Interesse nuoto = new Interesse("Nuoto");
    static Interesse moto = new Interesse("Moto");
    static Utente Mario = new Utente("Mario");

    public static void main(String[] args) {
        Mario.aggiungiInteresse(nuoto);
        Mario.aggiungiInteresse(moto);

        Interesse lettura = new Interesse("Lettura");
        Mario.aggiungiInteresse(lettura);
        Interesse universita = new Interesse("Universita'");
        Interesse cucina = new Interesse("Cucina");
        Interesse giardinaggio = new Interesse("Giardinaggio");
        Mario.aggiungiInteresse(cucina);

        Utente Luigi = new Utente("Luigi");
        Luigi.aggiungiInteresse(cucina);
        Luigi.aggiungiInteresse(universita);
        Luigi.aggiungiInteresse(moto);

        Utente Sara = new Utente("Sara");
        Sara.aggiungiInteresse(cucina);
        Sara.aggiungiInteresse(universita);
        Sara.aggiungiInteresse(nuoto);

        TinderLike tinder = new TinderLike();
        tinder.insertUtente(Luigi);
        tinder.insertUtente(Sara);
        tinder.insertUtente(Luigi);
        tinder.insertUtente(Mario);
        System.out.println(tinder);

        System.out.println(tinder.cancelUtente(Mario));
        tinder.insertUtente(Mario);
        Utente Francesco = new Utente("Francesco");
        Francesco.aggiungiInteresse(cucina);
        Francesco.aggiungiInteresse(moto);
        Francesco.aggiungiInteresse(universita);
        tinder.insertUtente(Francesco);
        System.out.println(tinder.obtainSimilarUtente(Francesco));

        //Controllo che gli utenti piu' simili corrispondono
        System.out.println(tinder.obtain2MostSimilarUtenti());

        Interesse giadinaggio = new Interesse("Giardinaggio");
        Mario.aggiungiInteresse(giadinaggio);
        Sara.aggiungiInteresse(giadinaggio);
        Interesse tennis = new Interesse("Tennis");
        Mario.aggiungiInteresse(tennis);
        Sara.aggiungiInteresse(tennis);
        Interesse calcio = new Interesse("Calcio");
        Mario.aggiungiInteresse(calcio);
        Sara.aggiungiInteresse(calcio);

        //Controllo l'aggiornamento degli interessi; mi deve risultare Mario e Sara
        System.out.println(tinder.obtain2MostSimilarUtenti());
        System.out.println(tinder.obtainSimilarUtente(Sara));

        System.out.println(tinder.cancelUtente(Sara));
        System.out.println(tinder.cancelUtente(Sara));
        tinder.insertUtente(Sara);




    }


}
