import java.util.Objects;
import java.util.UUID;

public class Interesse {
    private UUID codiceUnivoco;
    private String testo;

    public Interesse(String testo) {
        this.codiceUnivoco = UUID.randomUUID();
        this.testo = testo;
    }

    public String getTesto() {
        return testo;
    }

    @Override
    public String toString() {
        return "Interesse{" +
                "testo='" + testo + '\'' +
                '}';
    }
}


